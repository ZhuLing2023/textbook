package com.example.textbook;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class DrawActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
